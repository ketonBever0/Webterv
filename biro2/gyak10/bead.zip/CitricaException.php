<?php

class CitricaException extends Exception
{

    public function __construct()
    {
        parent::__construct("Baj van a Citricakkal!");
    }


}


