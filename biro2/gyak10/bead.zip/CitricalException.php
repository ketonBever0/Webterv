<?php

class CitricalException extends Exception
{

    public function __construct()
    {
        parent::__construct("Baj van a Citricakkal!");
    }




}


